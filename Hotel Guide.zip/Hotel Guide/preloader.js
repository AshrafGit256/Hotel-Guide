const preloader = document.querySelector("[data-preaload]");

window.addEventListener("load", function () {
   setTimeout(function() {
       preloader.classList.add("loaded");
       document.body.classList.add("loaded");
   }, 5000); // Adjust the delay (in milliseconds) as needed
});
