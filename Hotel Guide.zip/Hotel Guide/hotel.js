// Add click event listener to each box
document.querySelectorAll('.box').forEach(box => {
    // Toggle description overlay visibility on click
    box.addEventListener('click', () => {
        box.querySelector('.description-overlay').classList.toggle('active');
    });
});



const progressCircle = document.querySelector(".autoplay-progress svg");
const progressContent = document.querySelector(".autoplay-progress span");

var swiper = new Swiper(".home-slider", {
  spaceBetween: 30,
  centeredSlides: true,
  autoplay: {
    delay: 5000,
    disableOnInteraction: false
  },
  pagination: {
    el: ".swiper-pagination",
    clickable: true
  },
 loop: true,
  on: {
    autoplayTimeLeft(s, time, progress) {
      progressCircle.style.setProperty("--progress", 1 - progress);
      progressContent.textContent = `${Math.ceil(time / 1000)}s`;
    }
  }
});

const preloader = document.querySelector("[data-preaload]");

window.addEventListener("load", function () {
   setTimeout(function() {
       preloader.classList.add("loaded");
       document.body.classList.add("loaded");
   }, 2000); // Adjust the delay (in milliseconds) as needed
});



$('#menuToggle').on('click', function() {
  var menuList = $('#menuList');
  var maxHeight = menuList.css('maxHeight');
  menuList.css('maxHeight', maxHeight === '0px' ? '100vh' : '0px');
});